module.exports = `
const x = 'hi';
`;
